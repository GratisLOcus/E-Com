# users/migrations/0004_fix_referral_codes.py
from django.db import migrations
import uuid

def generate_referral_codes(apps, schema_editor):
    CustomUser = apps.get_model('users', 'CustomUser')
    for user in CustomUser.objects.all():
        while True:
            code = str(uuid.uuid4().hex[:8]).upper()  # 8-character code
            if not CustomUser.objects.filter(referral_code=code).exists():
                user.referral_code = code
                user.save()
                break

class Migration(migrations.Migration):
    dependencies = [
        ('users', '0003_alter_customuser_options_customuser_date_of_birth_and_more'),
    ]

    operations = [
        migrations.RunPython(generate_referral_codes),
    ]